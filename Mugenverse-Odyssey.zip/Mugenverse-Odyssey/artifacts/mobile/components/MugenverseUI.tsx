import React from 'react';
import type { ReactNode } from 'react';
import {
  Image,
  ImageBackground,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Feather } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { LinearGradient } from 'expo-linear-gradient';
import { useColors } from '@/hooks/useColors';
import type { Story } from '@/data/stories';

const logoMark = require('../assets/images/icon.png');

export function ScreenPage({
  children,
  contentContainerStyle,
}: {
  children: ReactNode;
  contentContainerStyle?: object;
}) {
  const colors = useColors();
  const insets = useSafeAreaInsets();

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
      <ScrollView
        keyboardShouldPersistTaps="handled"
        keyboardDismissMode="on-drag"
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.pageContent,
          {
            paddingTop: Platform.OS === 'web' ? 67 : 12,
            paddingBottom:
              Platform.OS === 'web' ? 34 : Math.max(22, insets.bottom + 18),
          },
          contentContainerStyle,
        ]}
      >
        {children}
      </ScrollView>
    </SafeAreaView>
  );
}

export function BrandHeader({
  subtitle = 'Histórias sem limites. Mundos sem fronteiras.',
  trailing,
}: {
  subtitle?: string;
  trailing?: ReactNode;
}) {
  const colors = useColors();

  return (
    <View style={styles.brandHeader}>
      <View style={styles.brandIdentity}>
        <Image source={logoMark} style={styles.logoMark} />
        <View>
          <Text style={[styles.brandName, { color: colors.foreground }]}>
            MUGENVERSE
          </Text>
          <Text style={[styles.brandSubtitle, { color: colors.mutedForeground }]}>
            {subtitle}
          </Text>
        </View>
      </View>
      {trailing}
    </View>
  );
}

export function PageHeading({
  eyebrow,
  title,
  description,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
}) {
  const colors = useColors();

  return (
    <View style={styles.pageHeading}>
      {eyebrow ? (
        <Text style={[styles.eyebrow, { color: colors.gold }]}>{eyebrow}</Text>
      ) : null}
      <Text style={[styles.pageTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      {description ? (
        <Text style={[styles.pageDescription, { color: colors.mutedForeground }]}>
          {description}
        </Text>
      ) : null}
    </View>
  );
}

export function SectionHeading({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  const colors = useColors();

  return (
    <View style={styles.sectionHeading}>
      <Text style={[styles.sectionTitle, { color: colors.foreground }]}>
        {title}
      </Text>
      {action && onAction ? (
        <Pressable
          accessibilityRole="button"
          onPress={onAction}
          hitSlop={8}
        >
          <Text style={[styles.sectionAction, { color: colors.gold }]}>
            {action}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

export function PrimaryButton({
  label,
  onPress,
  icon = 'arrow-up-right',
  disabled = false,
  testID,
}: {
  label: string;
  onPress: () => void;
  icon?: keyof typeof Feather.glyphMap;
  disabled?: boolean;
  testID?: string;
}) {
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ disabled }}
      testID={testID}
      disabled={disabled}
      onPress={() => {
        void Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        onPress();
      }}
      style={({ pressed }) => [
        styles.primaryButton,
        {
          backgroundColor: disabled ? colors.muted : colors.primary,
          opacity: pressed ? 0.86 : 1,
        },
      ]}
    >
      <Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>
        {label}
      </Text>
      <Feather name={icon} size={17} color={colors.primaryForeground} />
    </Pressable>
  );
}

export function ChoiceChip({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[
        styles.choiceChip,
        {
          backgroundColor: selected ? colors.accent : colors.card,
          borderColor: selected ? colors.primary : colors.border,
        },
      ]}
    >
      <Text
        style={[
          styles.choiceChipText,
          { color: selected ? colors.foreground : colors.mutedForeground },
        ]}
      >
        {label}
      </Text>
    </Pressable>
  );
}

export function StoryPosterCard({
  story,
  onPress,
}: {
  story: Story;
  onPress: () => void;
}) {
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Abrir história ${story.title}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.posterCard,
        { opacity: pressed ? 0.88 : 1 },
      ]}
    >
      <ImageBackground
        source={story.cover}
        resizeMode="cover"
        style={styles.posterImage}
        imageStyle={styles.posterImageRadius}
      >
        <LinearGradient
          colors={['transparent', 'rgba(8,7,12,0.35)', 'rgba(8,7,12,0.96)']}
          locations={[0.28, 0.62, 1]}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.posterBadge}>
          <Text style={[styles.posterBadgeText, { color: colors.gold }]}>
            {story.genre.toUpperCase()}
          </Text>
        </View>
        <View style={styles.posterCopy}>
          <Text style={styles.posterTitle} numberOfLines={2}>
            {story.title}
          </Text>
          <Text style={styles.posterMeta}>
            {story.chapterCount} capítulos · {story.readingTime}
          </Text>
        </View>
      </ImageBackground>
    </Pressable>
  );
}

export function StoryRow({
  story,
  onPress,
  note,
  progress,
  actionLabel,
}: {
  story: Story;
  onPress: () => void;
  note?: string;
  progress?: number;
  actionLabel?: string;
}) {
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={`Abrir história ${story.title}`}
      onPress={onPress}
      style={({ pressed }) => [
        styles.storyRow,
        { backgroundColor: colors.card, borderColor: colors.border, opacity: pressed ? 0.88 : 1 },
      ]}
    >
      <Image source={story.cover} style={styles.rowImage} />
      <View style={styles.rowCopy}>
        <Text style={[styles.rowGenre, { color: colors.gold }]}>
          {story.genre.toUpperCase()}
        </Text>
        <Text style={[styles.rowTitle, { color: colors.foreground }]} numberOfLines={1}>
          {story.title}
        </Text>
        <Text style={[styles.rowDescription, { color: colors.mutedForeground }]} numberOfLines={2}>
          {note ?? story.description}
        </Text>
        {typeof progress === 'number' ? (
          <View style={[styles.progressTrack, { backgroundColor: colors.secondary }]}>
            <View
              style={[
                styles.progressFill,
                { backgroundColor: colors.primary, width: `${Math.max(10, progress)}%` },
              ]}
            />
          </View>
        ) : (
          <Text style={[styles.rowMeta, { color: colors.mutedForeground }]}>
            {story.chapterCount} capítulos · {story.readingTime}
          </Text>
        )}
      </View>
      <View style={styles.rowAction}>
        {actionLabel ? (
          <Text style={[styles.rowActionText, { color: colors.primary }]}>
            {actionLabel}
          </Text>
        ) : (
          <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
        )}
      </View>
    </Pressable>
  );
}

export function EmptyState({
  title,
  description,
  icon = 'book-open',
}: {
  title: string;
  description: string;
  icon?: keyof typeof Feather.glyphMap;
}) {
  const colors = useColors();

  return (
    <View style={[styles.emptyState, { borderColor: colors.border }]}>
      <View style={[styles.emptyIcon, { backgroundColor: colors.secondary }]}>
        <Feather name={icon} size={22} color={colors.primary} />
      </View>
      <Text style={[styles.emptyTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.emptyDescription, { color: colors.mutedForeground }]}>
        {description}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  pageContent: { paddingHorizontal: 20, gap: 24 },
  brandHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  brandIdentity: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  logoMark: { width: 38, height: 38, borderRadius: 12 },
  brandName: { fontFamily: 'Inter_700Bold', fontSize: 15, letterSpacing: 2.1 },
  brandSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 10, marginTop: 3 },
  pageHeading: { gap: 6 },
  eyebrow: { fontFamily: 'Inter_600SemiBold', fontSize: 10, letterSpacing: 1.7 },
  pageTitle: { fontFamily: 'Inter_700Bold', fontSize: 27, letterSpacing: -0.7 },
  pageDescription: {
    fontFamily: 'Inter_400Regular',
    fontSize: 13,
    lineHeight: 20,
    maxWidth: 330,
  },
  sectionHeading: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 13,
  },
  sectionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 17, letterSpacing: -0.3 },
  sectionAction: { fontFamily: 'Inter_600SemiBold', fontSize: 11, letterSpacing: 0.3 },
  primaryButton: {
    minHeight: 52,
    borderRadius: 15,
    paddingHorizontal: 18,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  primaryButtonText: { fontFamily: 'Inter_700Bold', fontSize: 12, letterSpacing: 1.1 },
  choiceChip: {
    paddingHorizontal: 15,
    paddingVertical: 10,
    borderRadius: 100,
    borderWidth: 1,
  },
  choiceChipText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
  posterCard: { width: 160, borderRadius: 20, overflow: 'hidden' },
  posterImage: { height: 210, justifyContent: 'space-between', padding: 12 },
  posterImageRadius: { borderRadius: 20 },
  posterBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(12,10,18,0.82)',
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 7,
  },
  posterBadgeText: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.7 },
  posterCopy: { gap: 6 },
  posterTitle: { color: '#FFFFFF', fontFamily: 'Inter_700Bold', fontSize: 15, lineHeight: 20 },
  posterMeta: { color: 'rgba(255,255,255,0.72)', fontFamily: 'Inter_500Medium', fontSize: 9 },
  storyRow: {
    borderWidth: 1,
    borderRadius: 18,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    minHeight: 124,
  },
  rowImage: { width: 78, height: 102, borderRadius: 12 },
  rowCopy: { flex: 1, gap: 6 },
  rowGenre: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.8 },
  rowTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 13 },
  rowDescription: { fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 15 },
  rowMeta: { fontFamily: 'Inter_500Medium', fontSize: 9 },
  rowAction: { width: 48, alignItems: 'flex-end' },
  rowActionText: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 0.4 },
  progressTrack: { height: 4, borderRadius: 10, overflow: 'hidden', marginTop: 3 },
  progressFill: { height: '100%', borderRadius: 10 },
  emptyState: {
    borderWidth: 1,
    borderStyle: 'dashed',
    borderRadius: 20,
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 30,
    gap: 10,
  },
  emptyIcon: { width: 48, height: 48, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  emptyTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 14, textAlign: 'center' },
  emptyDescription: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 17, textAlign: 'center', maxWidth: 260 },
});
