import type {
  AttributeChanges,
  AttributeKey,
  Attributes,
  Story,
  StoryChoice,
  StoryScene,
} from '@/data/stories';
import { ATTRIBUTE_LABELS } from '@/data/stories';

export const INITIAL_ATTRIBUTES: Attributes = {
  strength: 5,
  intelligence: 5,
  agility: 5,
  charisma: 5,
  vitality: 5,
};

export const MIN_ATTRIBUTE = 1;
export const MAX_ATTRIBUTE = 20;
export const ACTION_DIFFICULTY = 8;

export type ActionIntent =
  | 'physical'
  | 'investigation'
  | 'movement'
  | 'social'
  | 'recovery'
  | 'arcane'
  | 'unsupported';

export interface ActionResolution {
  intent: ActionIntent;
  attributeKey: AttributeKey | null;
  outcome: 'favorável' | 'parcial' | 'sem-regra';
  attributeChanges: AttributeChanges;
  response: string;
}

function normalizeText(value: string): string {
  return value
    .normalize('NFD')
    .replace(/\p{Diacritic}/gu, '')
    .toLocaleLowerCase('pt-BR');
}

function containsAny(value: string, terms: string[]): boolean {
  return terms.some((term) => value.includes(term));
}

export function applyAttributeChanges(
  current: Attributes,
  changes: AttributeChanges,
): Attributes {
  return {
    strength: clamp(current.strength + (changes.strength ?? 0)),
    intelligence: clamp(current.intelligence + (changes.intelligence ?? 0)),
    agility: clamp(current.agility + (changes.agility ?? 0)),
    charisma: clamp(current.charisma + (changes.charisma ?? 0)),
    vitality: clamp(current.vitality + (changes.vitality ?? 0)),
  };
}

function clamp(value: number): number {
  return Math.max(MIN_ATTRIBUTE, Math.min(MAX_ATTRIBUTE, value));
}

export function resolveChoiceAttributeChanges(
  choice: StoryChoice,
): AttributeChanges {
  if (choice.attributeChanges) {
    return { ...choice.attributeChanges };
  }

  const text = normalizeText(`${choice.label} ${choice.consequence}`);
  if (
    containsAny(text, [
      'ouvir',
      'convers',
      'pergunt',
      'negoci',
      'convenc',
      'reunir',
      'pacto',
      'alianca',
      'recrut',
      'contar',
      'receber',
      'conhecer',
      'moradora',
      'abrir os portoes',
      'abrir o jardim',
      'cidades livres',
    ])
  ) {
    return { charisma: 1 };
  }
  if (
    containsAny(text, [
      'investig',
      'observ',
      'mapa',
      'escrever',
      'procur',
      'estud',
      'pista',
      'planej',
      'explor',
      'descobr',
      'analis',
      'rastre',
      'exam',
      'ler ',
    ])
  ) {
    return { intelligence: 1 };
  }
  if (
    containsAny(text, [
      'atac',
      'golpe',
      'lutar',
      'reforc',
      'defesa',
      'forca',
      'armas',
      'combate',
    ])
  ) {
    return { strength: 1 };
  }
  if (
    containsAny(text, [
      'atravess',
      'seguir',
      'fugir',
      'escap',
      'rota',
      'partir',
      'acompanhar',
      'caminho',
      'passagem',
      'portal',
    ])
  ) {
    return { agility: 1 };
  }
  if (
    containsAny(text, [
      'proteger',
      'segur',
      'reconstru',
      'restaur',
      'curar',
      'recuper',
      'preserv',
      'santuario',
      'abrigo',
    ])
  ) {
    return { vitality: 1 };
  }
  return {};
}

function classifyAction(action: string): {
  intent: ActionIntent;
  attributeKey: AttributeKey | null;
  label: string;
} {
  const text = normalizeText(action);

  if (containsAny(text, ['convers', 'pergunt', 'negoci', 'convenc', 'dialog', 'falar', 'ajudar', 'explicar', 'chamar'])) {
    return { intent: 'social', attributeKey: 'charisma', label: 'interação social' };
  }
  if (containsAny(text, ['investig', 'observ', 'exam', 'analis', 'pesquis', 'estud', 'procur', 'descobr', 'mapear', 'ler ', 'escut', 'rastre', 'inspec'])) {
    return { intent: 'investigation', attributeKey: 'intelligence', label: 'investigação' };
  }
  if (containsAny(text, ['feitic', 'magia', 'magico', 'encant', 'runa', 'invoc', 'conjur', 'arcano'])) {
    return { intent: 'arcane', attributeKey: 'intelligence', label: 'ação arcana' };
  }
  if (containsAny(text, ['atac', 'golpe', 'lutar', 'forcar', 'empurr', 'arrombar', 'quebrar', 'defender', 'carregar', 'levantar'])) {
    return { intent: 'physical', attributeKey: 'strength', label: 'esforço físico' };
  }
  if (containsAny(text, ['corr', 'esquiv', 'salt', 'escond', 'fug', 'escap', 'desviar', 'subir', 'seguir', 'caminh', 'aproxim', 'atravess', 'entrar', 'sair', 'mover'])) {
    return { intent: 'movement', attributeKey: 'agility', label: 'movimento ou evasão' };
  }
  if (containsAny(text, ['descans', 'curar', 'respir', 'recuper', 'dorm', 'tratar', 'comer'])) {
    return { intent: 'recovery', attributeKey: 'vitality', label: 'recuperação' };
  }
  return { intent: 'unsupported', attributeKey: null, label: 'ação sem regra local' };
}

export function resolveFreeAction(
  action: string,
  story: Story,
  scene: StoryScene,
  attributes: Attributes,
  attributesUsedThisChapter: AttributeKey[],
): ActionResolution {
  const cleanAction = action.trim().replace(/\s+/g, ' ').slice(0, 300);
  const classification = classifyAction(cleanAction);

  if (!classification.attributeKey) {
    return {
      ...classification,
      outcome: 'sem-regra',
      attributeChanges: {},
      response:
        `Ação registrada em “${scene.chapter}”: “${cleanAction}”. ` +
        'O motor local não reconhece uma regra para este tipo de ação. ' +
        'Nenhum resultado, atributo ou fato novo foi inventado. ' +
        'Tente uma ação de força, investigação, movimento, conversa, magia ou recuperação.',
    };
  }

  const key = classification.attributeKey;
  const score = attributes[key];
  const outcome = score >= ACTION_DIFFICULTY ? 'favorável' : 'parcial';
  const alreadyUsed = attributesUsedThisChapter.includes(key);
  const canImprove = !alreadyUsed && score < MAX_ATTRIBUTE;
  const attributeChanges: AttributeChanges = canImprove ? { [key]: 1 } : {};
  const nextScore = applyAttributeChanges(attributes, attributeChanges)[key];
  const growthNote = canImprove
    ? `${ATTRIBUTE_LABELS[key]} aumentou para ${nextScore}.`
    : alreadyUsed
      ? `${ATTRIBUTE_LABELS[key]} já teve um avanço neste capítulo; não há novo aumento por repetição.`
      : `${ATTRIBUTE_LABELS[key]} já está no limite de ${MAX_ATTRIBUTE}.`;

  return {
    ...classification,
    outcome,
    attributeChanges,
    response:
      `Ação registrada em “${scene.chapter}”: “${cleanAction}”. ` +
      `No mundo ${story.world}, o motor local classifica isso como ${classification.label}. ` +
      `Com ${ATTRIBUTE_LABELS[key]} ${score} e dificuldade ${ACTION_DIFFICULTY}, o resultado é ${outcome}. ` +
      `${growthNote} A cena continua neste capítulo; escolha uma opção para avançar a história.`,
  };
}
