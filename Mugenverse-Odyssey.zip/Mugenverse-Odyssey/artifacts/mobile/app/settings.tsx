import React, { useState } from 'react';
import {
  Pressable,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { PrimaryButton } from '@/components/MugenverseUI';
import { useAppState } from '@/context/AppContext';

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const {
    displayName,
    setDisplayName,
    notificationsEnabled,
    setNotificationsEnabled,
  } = useAppState();
  const [draftName, setDraftName] = useState(displayName);
  const [saved, setSaved] = useState(false);

  const saveProfile = () => {
    const nextName = draftName.trim();
    if (nextName.length < 2) {
      setSaved(false);
      return;
    }
    setDisplayName(nextName);
    setDraftName(nextName);
    setSaved(true);
  };

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
      <KeyboardAwareScrollViewCompat
        keyboardShouldPersistTaps="handled"
        bottomOffset={20}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top ? 10 : 18, paddingBottom: Math.max(26, insets.bottom + 20) },
        ]}
      >
        <View style={styles.topRow}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Voltar ao perfil"
            onPress={() => router.back()}
            style={[styles.backButton, { borderColor: colors.border }]}
          >
            <Feather name="arrow-left" size={17} color={colors.foreground} />
          </Pressable>
          <Text style={[styles.topTitle, { color: colors.foreground }]}>Configurações</Text>
          <View style={styles.topSpacer} />
        </View>

        <View style={styles.heading}>
          <Text style={[styles.eyebrow, { color: colors.gold }]}>SUA JORNADA</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>Preferências</Text>
          <Text style={[styles.description, { color: colors.mutedForeground }]}>
            Ajuste como o MUGENVERSE acompanha você.
          </Text>
        </View>

        <View style={[styles.section, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.sectionHeading}>
            <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
              <Feather name="user" size={16} color={colors.primary} />
            </View>
            <View style={styles.sectionCopy}>
              <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Nome de usuário</Text>
              <Text style={[styles.sectionDetail, { color: colors.mutedForeground }]}>
                Como você aparece nas suas histórias
              </Text>
            </View>
          </View>
          <TextInput
            accessibilityLabel="Nome de usuário"
            value={draftName}
            onChangeText={(value) => {
              setDraftName(value);
              setSaved(false);
            }}
            maxLength={32}
            placeholder="Seu nome"
            placeholderTextColor={colors.mutedForeground}
            style={[styles.nameInput, { backgroundColor: colors.background, color: colors.foreground, borderColor: colors.border }]}
          />
          {saved ? (
            <View style={styles.savedNotice}>
              <Feather name="check-circle" size={13} color={colors.success} />
              <Text style={[styles.savedText, { color: colors.success }]}>Perfil atualizado neste dispositivo.</Text>
            </View>
          ) : null}
          <PrimaryButton label="SALVAR ALTERAÇÕES" onPress={saveProfile} icon="check" />
        </View>

        <View style={[styles.preferenceRow, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.iconBox, { backgroundColor: colors.secondary }]}>
            <Feather name="bell" size={16} color={colors.gold} />
          </View>
          <View style={styles.sectionCopy}>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Lembretes</Text>
            <Text style={[styles.sectionDetail, { color: colors.mutedForeground }]}>
              Preferência local para futuras notificações
            </Text>
          </View>
          <Switch
            accessibilityLabel="Ativar lembretes"
            value={notificationsEnabled}
            onValueChange={setNotificationsEnabled}
            trackColor={{ false: colors.border, true: colors.primary }}
            thumbColor="#FFFFFF"
          />
        </View>

        <View style={[styles.localNotice, { backgroundColor: colors.secondary }]}>
          <Feather name="hard-drive" size={15} color={colors.gold} />
          <Text style={[styles.localNoticeText, { color: colors.secondaryForeground }]}>
            Perfil, histórias criadas e progresso são armazenados localmente. Nenhum banco de dados ou serviço de IA está conectado nesta versão.
          </Text>
        </View>
      </KeyboardAwareScrollViewCompat>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 21 },
  topRow: { minHeight: 42, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  backButton: { width: 36, height: 36, borderRadius: 12, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  topTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  topSpacer: { width: 36 },
  heading: { gap: 6 },
  eyebrow: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.5 },
  title: { fontFamily: 'Inter_700Bold', fontSize: 26, letterSpacing: -0.5 },
  description: { fontFamily: 'Inter_400Regular', fontSize: 11, lineHeight: 18 },
  section: { borderWidth: 1, borderRadius: 18, padding: 15, gap: 13 },
  sectionHeading: { flexDirection: 'row', alignItems: 'center', gap: 11 },
  iconBox: { width: 38, height: 38, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  sectionCopy: { flex: 1, gap: 4 },
  sectionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  sectionDetail: { fontFamily: 'Inter_400Regular', fontSize: 9, lineHeight: 14 },
  nameInput: { minHeight: 46, borderRadius: 12, borderWidth: 1, paddingHorizontal: 12, fontFamily: 'Inter_400Regular', fontSize: 11 },
  savedNotice: { flexDirection: 'row', gap: 7, alignItems: 'center' },
  savedText: { fontFamily: 'Inter_500Medium', fontSize: 9 },
  preferenceRow: { borderWidth: 1, borderRadius: 17, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11 },
  localNotice: { borderRadius: 14, padding: 13, flexDirection: 'row', alignItems: 'flex-start', gap: 9 },
  localNoticeText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 17 },
});
