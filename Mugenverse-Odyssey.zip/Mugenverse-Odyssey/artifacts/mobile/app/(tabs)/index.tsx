import React from 'react';
import {
  ImageBackground,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { ScreenPage, BrandHeader, SectionHeading, StoryPosterCard, StoryRow } from '@/components/MugenverseUI';
import { HERO_IMAGE, STORIES } from '@/data/stories';
import { useAppState } from '@/context/AppContext';
import type { Story } from '@/data/stories';

function openStory(story: Story) {
  router.push({ pathname: '/story/[id]', params: { id: story.id } });
}

export default function HomeScreen() {
  const colors = useColors();
  const { journeys, customStories, startAdventure } = useAppState();
  const allStories = [...customStories, ...STORIES];
  const ongoing = Object.entries(journeys)
    .filter(([, journey]) => journey.status === 'in-progress')
    .sort((a, b) => b[1].updatedAt - a[1].updatedAt)
    .map(([id]) => allStories.find((story) => story.id === id))
    .filter((story): story is Story => Boolean(story));
  const popularStories = STORIES.filter((story) => story.isPopular);
  const newStories = STORIES.filter((story) => story.isNew);
  const featuredStory = STORIES[0];

  const beginFeatured = () => {
    startAdventure(featuredStory.id);
    openStory(featuredStory);
  };

  return (
    <ScreenPage contentContainerStyle={{ gap: 22 }}>
      <BrandHeader
        trailing={
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Abrir perfil"
            onPress={() => router.push('/(tabs)/profile')}
            style={[styles.headerButton, { borderColor: colors.border }]}
          >
            <Feather name="user" size={17} color={colors.gold} />
          </Pressable>
        }
      />

      <ImageBackground
        source={HERO_IMAGE}
        style={styles.hero}
        imageStyle={styles.heroImage}
        resizeMode="cover"
      >
        <LinearGradient
          colors={['rgba(8,7,12,0.06)', 'rgba(8,7,12,0.42)', 'rgba(8,7,12,0.96)']}
          locations={[0.08, 0.45, 1]}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.heroTopline}>
          <View style={styles.heroLabel}>
            <View style={[styles.liveDot, { backgroundColor: colors.gold }]} />
            <Text style={styles.heroLabelText}>SEU PRÓXIMO MUNDO</Text>
          </View>
          <Feather name="star" size={17} color={colors.gold} />
        </View>
        <View style={styles.heroCopy}>
          <Text style={styles.heroEyebrow}>UMA HISTÓRIA ORIGINAL</Text>
          <Text style={styles.heroTitle}>Um outro mundo{'\n'}te espera.</Text>
          <Text style={styles.heroDescription}>
            Reescreva o destino de Aetherion.
          </Text>
          <Pressable
            accessibilityRole="button"
            testID="start-featured-adventure"
            onPress={beginFeatured}
            style={({ pressed }) => [
              styles.heroButton,
              { backgroundColor: colors.primary, opacity: pressed ? 0.88 : 1 },
            ]}
          >
            <Text style={styles.heroButtonText}>COMEÇAR AVENTURA</Text>
            <Feather name="arrow-up-right" size={16} color="#FFFFFF" />
          </Pressable>
        </View>
      </ImageBackground>

      {ongoing.length > 0 ? (
        <View>
          <SectionHeading
            title="Continuar jogando"
            action="Ver tudo"
            onAction={() => router.push('/(tabs)/library')}
          />
          <StoryRow
            story={ongoing[0]}
            note={`Capítulo ${(journeys[ongoing[0].id]?.sceneIndex ?? 0) + 1} · Sua jornada aguarda`}
            progress={Math.round(
              (((journeys[ongoing[0].id]?.sceneIndex ?? 0) + 1) /
                Math.max(1, ongoing[0].scenes.length)) *
                100,
            )}
            actionLabel="CONTINUAR"
            onPress={() => openStory(ongoing[0])}
          />
        </View>
      ) : null}

      <View>
        <SectionHeading
          title="Histórias populares"
          action="Explorar"
          onAction={() => router.push('/(tabs)/explore')}
        />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.posterList}>
          {popularStories.map((story) => (
            <StoryPosterCard key={story.id} story={story} onPress={() => openStory(story)} />
          ))}
        </ScrollView>
      </View>

      <View>
        <SectionHeading
          title="Recém-chegadas"
          action="Ver catálogo"
          onAction={() => router.push('/(tabs)/explore')}
        />
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.posterList}>
          {newStories.map((story) => (
            <StoryPosterCard key={story.id} story={story} onPress={() => openStory(story)} />
          ))}
        </ScrollView>
      </View>
      <View style={[styles.footerNote, { borderColor: colors.border }]}>
        <Feather name="moon" size={15} color={colors.gold} />
        <Text style={[styles.footerText, { color: colors.mutedForeground }]}>
          Histórias sem limites. Mundos sem fronteiras.
        </Text>
      </View>
    </ScreenPage>
  );
}

const styles = StyleSheet.create({
  headerButton: {
    width: 38,
    height: 38,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderRadius: 13,
  },
  hero: {
    height: 352,
    borderRadius: 24,
    overflow: 'hidden',
    justifyContent: 'space-between',
    padding: 19,
  },
  heroImage: { borderRadius: 24 },
  heroTopline: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  heroLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 9,
    backgroundColor: 'rgba(8,7,12,0.68)',
  },
  liveDot: { width: 6, height: 6, borderRadius: 3 },
  heroLabelText: { color: '#FFFFFF', fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 1.1 },
  heroCopy: { gap: 9 },
  heroEyebrow: { color: '#D9B86C', fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.4 },
  heroTitle: { color: '#FFFFFF', fontFamily: 'Inter_700Bold', fontSize: 30, lineHeight: 35, letterSpacing: -0.8 },
  heroDescription: { color: 'rgba(255,255,255,0.76)', fontFamily: 'Inter_400Regular', fontSize: 12 },
  heroButton: {
    marginTop: 7,
    alignSelf: 'flex-start',
    height: 44,
    borderRadius: 13,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  heroButtonText: { color: '#FFFFFF', fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1 },
  posterList: { gap: 12, paddingRight: 20 },
  footerNote: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    borderTopWidth: StyleSheet.hairlineWidth,
    paddingTop: 18,
  },
  footerText: { fontFamily: 'Inter_400Regular', fontSize: 10 },
});
