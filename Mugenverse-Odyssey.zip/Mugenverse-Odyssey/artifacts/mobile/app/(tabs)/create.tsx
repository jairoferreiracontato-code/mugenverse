import React, { useState } from 'react';
import {
  Alert,
  Image,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { KeyboardAwareScrollViewCompat } from '@/components/KeyboardAwareScrollViewCompat';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { ChoiceChip, PageHeading, PrimaryButton } from '@/components/MugenverseUI';
import { GENRES } from '@/data/stories';
import type { Genre, Story } from '@/data/stories';
import { useAppState } from '@/context/AppContext';

type CreationMode = 'quick' | 'advanced';

const coverOptions = [
  require('../../assets/images/story-kingdom.jpg'),
  require('../../assets/images/story-archive.jpg'),
];

export default function CreateScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addStory } = useAppState();
  const [mode, setMode] = useState<CreationMode>('quick');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [genre, setGenre] = useState<Genre>('Isekai');
  const [world, setWorld] = useState('');
  const [protagonist, setProtagonist] = useState('');
  const [opening, setOpening] = useState('');
  const [coverIndex, setCoverIndex] = useState(0);

  const submit = () => {
    if (title.trim().length < 3) {
      Alert.alert('Nome da história', 'Digite um título com pelo menos 3 caracteres.');
      return;
    }
    if (description.trim().length < 12) {
      Alert.alert('Apresente sua história', 'Escreva uma descrição com pelo menos 12 caracteres.');
      return;
    }
    if (mode === 'advanced' && opening.trim().length < 20) {
      Alert.alert('Cena de abertura', 'Escreva pelo menos 20 caracteres para começar a aventura.');
      return;
    }

    const storyId = `criada-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
    const mainCharacter = protagonist.trim() || 'A pessoa recém-chegada';
    const worldName = world.trim() || 'Um mundo ainda sem nome';
    const initialText =
      mode === 'advanced'
        ? opening.trim()
        : `${description.trim()} Em ${worldName}, ${mainCharacter} tem diante de si o primeiro passo dessa jornada.`;
    const story: Story = {
      id: storyId,
      title: title.trim(),
      description: description.trim(),
      genre,
      tags: [genre],
      world: worldName,
      protagonist: mainCharacter,
      author: 'Sua criação',
      chapterCount: 3,
      readingTime: 'Nova jornada',
      cover: coverOptions[coverIndex],
      isUserCreated: true,
      isNew: true,
      scenes: [
        {
          chapter: 'O primeiro passo',
          narration: initialText,
          choices: [
            {
              label: 'Seguir a pista mais próxima',
              consequence: `${mainCharacter} segue em direção ao desconhecido de ${worldName}.`,
            },
            {
              label: 'Procurar alguém em quem confiar',
              consequence: `${mainCharacter} encontra uma nova perspectiva para compreender ${worldName}.`,
            },
          ],
        },
        {
          chapter: 'Um mundo em movimento',
          narration: `${mainCharacter} percebe que a chegada a ${worldName} mudou mais do que o próprio caminho. Uma decisão agora pode abrir espaço para novas alianças.`,
          choices: [
            {
              label: 'Construir uma aliança',
              consequence: 'Uma nova parceria começa a ganhar forma.',
            },
            {
              label: 'Investigar por conta própria',
              consequence: 'Uma descoberta inesperada muda o rumo da jornada.',
            },
          ],
        },
        {
          chapter: 'A escolha é sua',
          narration: `A primeira etapa em ${worldName} chega ao fim. A próxima parte deste universo continua a partir das ideias que você criar.`,
          choices: [
            {
              label: 'Proteger este novo começo',
              consequence: 'O mundo está salvo no início de uma nova história.',
            },
            {
              label: 'Partir em busca de outro horizonte',
              consequence: 'Uma nova jornada aguarda quando você decidir continuar.',
            },
          ],
        },
      ],
    };

    addStory(story);
    setTitle('');
    setDescription('');
    setWorld('');
    setProtagonist('');
    setOpening('');
    Alert.alert(
      'Universo criado',
      'Sua história foi salva na biblioteca deste dispositivo.',
      [
        {
          text: 'Ver na biblioteca',
          onPress: () => router.push('/(tabs)/library'),
        },
        { text: 'Continuar criando', style: 'cancel' },
      ],
    );
  };

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
      <KeyboardAwareScrollViewCompat
        keyboardShouldPersistTaps="handled"
        bottomOffset={24}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          { paddingTop: insets.top ? 12 : 20, paddingBottom: Math.max(28, insets.bottom + 20) },
        ]}
      >
        <PageHeading
          eyebrow="AUTORIA SEM FRONTEIRAS"
          title="Forje seu universo"
          description="Crie mundos, personagens e escolhas que levam a uma aventura jogável."
        />

        <View style={[styles.modePanel, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.modeHeading}>
            <Feather name="compass" size={16} color={colors.gold} />
            <Text style={[styles.modeTitle, { color: colors.foreground }]}>
              Como quer começar?
            </Text>
          </View>
          <View style={styles.modeSwitch}>
            <ModeOption
              title="Criação rápida"
              detail="Uma ideia vira aventura"
              selected={mode === 'quick'}
              onPress={() => setMode('quick')}
            />
            <ModeOption
              title="Criação avançada"
              detail="Defina os detalhes"
              selected={mode === 'advanced'}
              onPress={() => setMode('advanced')}
            />
          </View>
        </View>

        <View style={styles.formSection}>
          <FieldLabel label="Título da história" required />
          <TextInput
            testID="create-story-title"
            value={title}
            onChangeText={setTitle}
            placeholder="Ex.: O reino além do portal"
            placeholderTextColor={colors.mutedForeground}
            maxLength={60}
            style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]}
          />
        </View>

        <View style={styles.formSection}>
          <FieldLabel label="Gênero principal" required />
          <View style={styles.genreGrid}>
            {GENRES.map((item) => (
              <ChoiceChip
                key={item}
                label={item}
                selected={genre === item}
                onPress={() => setGenre(item)}
              />
            ))}
          </View>
        </View>

        <View style={styles.formSection}>
          <FieldLabel label="Sinopse" required />
          <TextInput
            testID="create-story-description"
            value={description}
            onChangeText={setDescription}
            placeholder="Qual é a grande promessa desta aventura?"
            placeholderTextColor={colors.mutedForeground}
            maxLength={240}
            multiline
            textAlignVertical="top"
            style={[styles.input, styles.multiline, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]}
          />
          <Text style={[styles.fieldHint, { color: colors.mutedForeground }]}>
            {description.length}/240 caracteres
          </Text>
        </View>

        <View style={styles.formSection}>
          <FieldLabel label="Capa da história" />
          <View style={styles.coverOptions}>
            {coverOptions.map((cover, index) => (
              <Pressable
                key={index}
                accessibilityRole="button"
                accessibilityLabel={`Selecionar capa ${index + 1}`}
                accessibilityState={{ selected: coverIndex === index }}
                onPress={() => setCoverIndex(index)}
                style={[
                  styles.coverChoice,
                  { borderColor: coverIndex === index ? colors.gold : colors.border },
                ]}
              >
                <Image source={cover} style={styles.coverImage} />
                {coverIndex === index ? (
                  <View style={[styles.coverCheck, { backgroundColor: colors.gold }]}>
                    <Feather name="check" size={12} color={colors.background} />
                  </View>
                ) : null}
              </Pressable>
            ))}
          </View>
        </View>

        {mode === 'advanced' ? (
          <>
            <View style={styles.formSection}>
              <FieldLabel label="Nome do mundo" />
              <TextInput
                value={world}
                onChangeText={setWorld}
                placeholder="Ex.: Aetherion"
                placeholderTextColor={colors.mutedForeground}
                maxLength={60}
                style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]}
              />
            </View>
            <View style={styles.formSection}>
              <FieldLabel label="Personagem principal" />
              <TextInput
                value={protagonist}
                onChangeText={setProtagonist}
                placeholder="Nome ou descrição do protagonista"
                placeholderTextColor={colors.mutedForeground}
                maxLength={80}
                style={[styles.input, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]}
              />
            </View>
            <View style={styles.formSection}>
              <FieldLabel label="Cena de abertura" required />
              <TextInput
                value={opening}
                onChangeText={setOpening}
                placeholder="Escreva o primeiro momento jogável da aventura."
                placeholderTextColor={colors.mutedForeground}
                maxLength={600}
                multiline
                textAlignVertical="top"
                style={[styles.input, styles.multiline, styles.openingInput, { color: colors.foreground, backgroundColor: colors.card, borderColor: colors.border }]}
              />
            </View>
          </>
        ) : (
          <View style={[styles.quickNote, { backgroundColor: colors.secondary }]}>
            <Feather name="zap" size={15} color={colors.gold} />
            <Text style={[styles.quickNoteText, { color: colors.secondaryForeground }]}>
              Seu universo será salvo com uma aventura inicial editável em futuras etapas.
            </Text>
          </View>
        )}

        <PrimaryButton
          label="CRIAR MINHA HISTÓRIA"
          onPress={submit}
          icon="plus"
          testID="save-created-story"
        />
        <Text style={[styles.localNote, { color: colors.mutedForeground }]}>
          Nesta versão, suas criações ficam salvas apenas neste dispositivo.
        </Text>
      </KeyboardAwareScrollViewCompat>
    </SafeAreaView>
  );
}

function ModeOption({
  title,
  detail,
  selected,
  onPress,
}: {
  title: string;
  detail: string;
  selected: boolean;
  onPress: () => void;
}) {
  const colors = useColors();

  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected }}
      onPress={onPress}
      style={[
        styles.modeOption,
        {
          backgroundColor: selected ? colors.accent : 'transparent',
          borderColor: selected ? colors.primary : colors.border,
        },
      ]}
    >
      <Text style={[styles.modeOptionTitle, { color: colors.foreground }]}>{title}</Text>
      <Text style={[styles.modeOptionDetail, { color: colors.mutedForeground }]}>{detail}</Text>
    </Pressable>
  );
}

function FieldLabel({ label, required = false }: { label: string; required?: boolean }) {
  const colors = useColors();

  return (
    <View style={styles.fieldLabelRow}>
      <Text style={[styles.fieldLabel, { color: colors.foreground }]}>{label}</Text>
      {required ? <Text style={[styles.required, { color: colors.gold }]}>OBRIGATÓRIO</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  content: { paddingHorizontal: 20, gap: 19 },
  modePanel: { borderWidth: 1, borderRadius: 18, padding: 14, gap: 12 },
  modeHeading: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  modeTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  modeSwitch: { flexDirection: 'row', gap: 9 },
  modeOption: { flex: 1, borderWidth: 1, borderRadius: 13, padding: 11, gap: 5 },
  modeOptionTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 10 },
  modeOptionDetail: { fontFamily: 'Inter_400Regular', fontSize: 9 },
  formSection: { gap: 8 },
  fieldLabelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  fieldLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 11 },
  required: { fontFamily: 'Inter_700Bold', fontSize: 8, letterSpacing: 0.6 },
  input: {
    minHeight: 48,
    borderWidth: 1,
    borderRadius: 13,
    paddingHorizontal: 13,
    paddingVertical: 12,
    fontFamily: 'Inter_400Regular',
    fontSize: 11,
  },
  multiline: { height: 92, lineHeight: 18 },
  openingInput: { height: 120 },
  fieldHint: { alignSelf: 'flex-end', fontFamily: 'Inter_400Regular', fontSize: 9 },
  genreGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 7 },
  coverOptions: { flexDirection: 'row', gap: 12 },
  coverChoice: { width: 80, height: 105, borderRadius: 13, borderWidth: 2, overflow: 'hidden' },
  coverImage: { width: '100%', height: '100%' },
  coverCheck: {
    position: 'absolute',
    right: 6,
    top: 6,
    width: 21,
    height: 21,
    borderRadius: 11,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickNote: { flexDirection: 'row', gap: 9, alignItems: 'flex-start', padding: 13, borderRadius: 13 },
  quickNoteText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 16 },
  localNote: { textAlign: 'center', fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: -7 },
});
