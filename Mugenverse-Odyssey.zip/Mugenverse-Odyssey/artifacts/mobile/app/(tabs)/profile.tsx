import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import { EmptyState, PageHeading, ScreenPage } from '@/components/MugenverseUI';
import { STORIES } from '@/data/stories';
import { useAppState } from '@/context/AppContext';

export default function ProfileScreen() {
  const colors = useColors();
  const { customStories, journeys, displayName, storageError } = useAppState();
  const allStories = [...customStories, ...STORIES];
  const startedCount = Object.values(journeys).filter(
    (journey) => journey.status === 'in-progress' || journey.status === 'completed',
  ).length;
  const createdCount = customStories.length;

  return (
    <ScreenPage contentContainerStyle={{ gap: 20 }}>
      <PageHeading eyebrow="SUA IDENTIDADE" title="Perfil" />

      <View style={[styles.profileCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <View style={[styles.avatar, { backgroundColor: colors.accent, borderColor: colors.gold }]}>
          <Text style={[styles.avatarInitial, { color: colors.gold }]}>
            {(displayName.trim()[0] || 'V').toLocaleUpperCase('pt-BR')}
          </Text>
        </View>
        <View style={styles.profileCopy}>
          <Text style={[styles.profileName, { color: colors.foreground }]}>{displayName}</Text>
          <Text style={[styles.profileSubtitle, { color: colors.mutedForeground }]}>
            Explorador do Mugenverse
          </Text>
        </View>
        <Pressable
          accessibilityRole="button"
          accessibilityLabel="Editar perfil"
          onPress={() => router.push('/settings')}
          style={[styles.editButton, { borderColor: colors.border }]}
        >
          <Feather name="edit-2" size={15} color={colors.foreground} />
        </Pressable>
      </View>

      <View style={styles.statsRow}>
        <ProfileStat label="HISTÓRIAS CRIADAS" value={createdCount} />
        <ProfileStat label="AVENTURAS INICIADAS" value={startedCount} />
        <ProfileStat
          label="CONCLUÍDAS"
          value={Object.values(journeys).filter((journey) => journey.status === 'completed').length}
        />
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={() => router.push('/settings')}
        style={({ pressed }) => [
          styles.settingRow,
          { borderColor: colors.border, backgroundColor: colors.card, opacity: pressed ? 0.85 : 1 },
        ]}
      >
        <View style={[styles.settingIcon, { backgroundColor: colors.secondary }]}>
          <Feather name="settings" size={17} color={colors.primary} />
        </View>
        <View style={styles.settingCopy}>
          <Text style={[styles.settingTitle, { color: colors.foreground }]}>Configurações</Text>
          <Text style={[styles.settingDetail, { color: colors.mutedForeground }]}>
            Perfil, preferências e notificações
          </Text>
        </View>
        <Feather name="chevron-right" size={17} color={colors.mutedForeground} />
      </Pressable>

      {storageError ? (
        <View style={[styles.storageNotice, { backgroundColor: colors.secondary }]}>
          <Feather name="alert-circle" size={15} color={colors.gold} />
          <Text style={[styles.storageNoticeText, { color: colors.secondaryForeground }]}>
            {storageError}
          </Text>
        </View>
      ) : null}

      <View style={[styles.aboutCard, { borderColor: colors.border }]}>
        <Feather name="moon" size={16} color={colors.gold} />
        <View style={styles.aboutCopy}>
          <Text style={[styles.aboutTitle, { color: colors.foreground }]}>MUGENVERSE</Text>
          <Text style={[styles.aboutDetail, { color: colors.mutedForeground }]}>
            Histórias sem limites. Mundos sem fronteiras.
          </Text>
          <Text style={[styles.version, { color: colors.mutedForeground }]}>
            Primeira versão · conteúdo demonstrativo
          </Text>
        </View>
      </View>

      {createdCount === 0 && allStories.length === 0 ? (
        <EmptyState title="Um universo à sua espera" description="Suas histórias aparecerão aqui." />
      ) : null}
    </ScreenPage>
  );
}

function ProfileStat({ label, value }: { label: string; value: number }) {
  const colors = useColors();

  return (
    <View style={[styles.statCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
      <Text style={[styles.statValue, { color: colors.gold }]}>{value}</Text>
      <Text style={[styles.statLabel, { color: colors.mutedForeground }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  profileCard: { borderWidth: 1, borderRadius: 20, padding: 16, flexDirection: 'row', alignItems: 'center', gap: 13 },
  avatar: { width: 58, height: 58, borderRadius: 20, borderWidth: 1, alignItems: 'center', justifyContent: 'center' },
  avatarInitial: { fontFamily: 'Inter_700Bold', fontSize: 23 },
  profileCopy: { flex: 1, gap: 5 },
  profileName: { fontFamily: 'Inter_700Bold', fontSize: 16 },
  profileSubtitle: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  editButton: { width: 34, height: 34, borderWidth: 1, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  statsRow: { flexDirection: 'row', gap: 8 },
  statCard: { flex: 1, minHeight: 86, borderWidth: 1, borderRadius: 15, padding: 11, justifyContent: 'center', gap: 5 },
  statValue: { fontFamily: 'Inter_700Bold', fontSize: 22 },
  statLabel: { fontFamily: 'Inter_600SemiBold', fontSize: 7, lineHeight: 10, letterSpacing: 0.5 },
  settingRow: { borderWidth: 1, borderRadius: 16, minHeight: 70, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 12 },
  settingIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  settingCopy: { flex: 1, gap: 4 },
  settingTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 12 },
  settingDetail: { fontFamily: 'Inter_400Regular', fontSize: 9 },
  storageNotice: { borderRadius: 13, padding: 12, flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  storageNoticeText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 16 },
  aboutCard: { borderTopWidth: StyleSheet.hairlineWidth, paddingTop: 17, flexDirection: 'row', alignItems: 'flex-start', gap: 11 },
  aboutCopy: { gap: 5 },
  aboutTitle: { fontFamily: 'Inter_700Bold', fontSize: 11, letterSpacing: 1.3 },
  aboutDetail: { fontFamily: 'Inter_400Regular', fontSize: 10 },
  version: { fontFamily: 'Inter_400Regular', fontSize: 9, marginTop: 3 },
});
