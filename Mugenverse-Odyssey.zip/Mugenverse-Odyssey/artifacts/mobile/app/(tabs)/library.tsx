import React, { useMemo, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import {
  ChoiceChip,
  EmptyState,
  PageHeading,
  ScreenPage,
  StoryRow,
} from '@/components/MugenverseUI';
import { STORIES } from '@/data/stories';
import type { Story } from '@/data/stories';
import { useAppState } from '@/context/AppContext';

type LibraryFilter = 'Tudo' | 'Criadas' | 'Em andamento' | 'Concluídas';

export default function LibraryScreen() {
  const colors = useColors();
  const { customStories, journeys } = useAppState();
  const [filter, setFilter] = useState<LibraryFilter>('Tudo');
  const allStories = useMemo(() => [...customStories, ...STORIES], [customStories]);
  const libraryStories = useMemo(() => {
    if (filter === 'Criadas') {
      return customStories;
    }
    if (filter === 'Em andamento') {
      return allStories.filter((story) => journeys[story.id]?.status === 'in-progress');
    }
    if (filter === 'Concluídas') {
      return allStories.filter((story) => journeys[story.id]?.status === 'completed');
    }
    return allStories.filter(
      (story) => story.isUserCreated || journeys[story.id] !== undefined,
    );
  }, [allStories, customStories, filter, journeys]);

  const openStory = (story: Story) => {
    router.push({ pathname: '/story/[id]', params: { id: story.id } });
  };

  return (
    <ScreenPage contentContainerStyle={{ gap: 21 }}>
      <PageHeading
        eyebrow="SEU REFÚGIO ENTRE MUNDOS"
        title="Biblioteca"
        description="Suas criações e jornadas ficam reunidas aqui."
      />
      <View style={styles.filters}>
        {(['Tudo', 'Criadas', 'Em andamento', 'Concluídas'] as LibraryFilter[]).map((item) => (
          <ChoiceChip
            key={item}
            label={item}
            selected={filter === item}
            onPress={() => setFilter(item)}
          />
        ))}
      </View>

      {libraryStories.length > 0 ? (
        <View style={styles.list}>
          {libraryStories.map((story) => {
            const journey = journeys[story.id];
            const isCompleted = journey?.status === 'completed';
            const progress = journey
              ? Math.round(
                  ((journey.sceneIndex + (isCompleted ? 1 : 0)) /
                    Math.max(1, story.scenes.length)) *
                    100,
                )
              : undefined;
            return (
              <StoryRow
                key={story.id}
                story={story}
                note={
                  story.isUserCreated
                    ? isCompleted
                      ? 'Criação sua · jornada concluída'
                      : journey
                        ? 'Criação sua · aventura iniciada'
                        : 'Criação sua · pronta para começar'
                    : isCompleted
                      ? 'Aventura concluída'
                      : journey
                        ? `Capítulo ${(journey.sceneIndex ?? 0) + 1} · em andamento`
                        : 'História disponível para começar'
                }
                progress={progress}
                actionLabel={journey?.status === 'completed' ? 'REVER' : journey ? 'CONTINUAR' : 'ABRIR'}
                onPress={() => openStory(story)}
              />
            );
          })}
        </View>
      ) : (
        <EmptyState
          icon={filter === 'Criadas' ? 'edit-3' : 'book-open'}
          title={
            filter === 'Criadas'
              ? 'Seu primeiro universo começa aqui'
              : filter === 'Em andamento'
                ? 'Nenhuma jornada em andamento'
                : filter === 'Concluídas'
                  ? 'Ainda não há finais registrados'
                  : 'Sua biblioteca está esperando'
          }
          description={
            filter === 'Criadas'
              ? 'Use a criação rápida ou avançada para dar forma a uma nova história.'
              : 'Explore o catálogo e escolha uma história para começar a jogar.'
          }
        />
      )}
      <View style={[styles.footer, { borderColor: colors.border }]} />
    </ScreenPage>
  );
}

const styles = StyleSheet.create({
  filters: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  list: { gap: 10 },
  footer: { height: 1, borderTopWidth: StyleSheet.hairlineWidth, marginTop: 1 },
});
