import React, { useMemo, useState } from 'react';
import {
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useColors } from '@/hooks/useColors';
import {
  ChoiceChip,
  EmptyState,
  PageHeading,
  ScreenPage,
  StoryRow,
} from '@/components/MugenverseUI';
import { GENRES, STORIES } from '@/data/stories';
import type { Genre, Story } from '@/data/stories';
import { useAppState } from '@/context/AppContext';

export default function ExploreScreen() {
  const colors = useColors();
  const { customStories } = useAppState();
  const [query, setQuery] = useState('');
  const [selectedGenre, setSelectedGenre] = useState<Genre | 'Tudo'>('Tudo');
  const allStories = useMemo(
    () => [...customStories, ...STORIES],
    [customStories],
  );
  const filteredStories = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase('pt-BR');
    return allStories.filter((story) => {
      const matchesGenre =
        selectedGenre === 'Tudo' || story.tags.includes(selectedGenre);
      const searchable = `${story.title} ${story.description} ${story.world} ${story.genre}`
        .toLocaleLowerCase('pt-BR');
      return matchesGenre && (!normalizedQuery || searchable.includes(normalizedQuery));
    });
  }, [allStories, query, selectedGenre]);

  const openStory = (story: Story) => {
    router.push({ pathname: '/story/[id]', params: { id: story.id } });
  };

  return (
    <ScreenPage contentContainerStyle={{ gap: 21 }}>
      <PageHeading
        eyebrow="ENCONTRE SEU PRÓXIMO DESTINO"
        title="Explorar mundos"
        description="Escolha uma porta. O que acontece depois depende de você."
      />

      <View style={[styles.searchBox, { backgroundColor: colors.card, borderColor: colors.border }]}>
        <Feather name="search" size={17} color={colors.mutedForeground} />
        <TextInput
          accessibilityLabel="Pesquisar histórias"
          testID="story-search"
          value={query}
          onChangeText={setQuery}
          placeholder="Buscar por título, mundo ou gênero"
          placeholderTextColor={colors.mutedForeground}
          autoCapitalize="none"
          returnKeyType="search"
          style={[styles.searchInput, { color: colors.foreground }]}
        />
        {query.length > 0 ? (
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Limpar pesquisa"
            onPress={() => setQuery('')}
            hitSlop={8}
          >
            <Feather name="x" size={17} color={colors.mutedForeground} />
          </Pressable>
        ) : null}
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.genreList}
      >
        <ChoiceChip
          label="Tudo"
          selected={selectedGenre === 'Tudo'}
          onPress={() => setSelectedGenre('Tudo')}
        />
        {GENRES.map((genre) => (
          <ChoiceChip
            key={genre}
            label={genre}
            selected={selectedGenre === genre}
            onPress={() => setSelectedGenre(genre)}
          />
        ))}
      </ScrollView>

      <View style={styles.catalogHeading}>
        <View>
          <PageHeading title="Catálogo" />
        </View>
        <View style={[styles.resultCount, { backgroundColor: colors.secondary }]}>
          <Feather name="layers" size={12} color={colors.primary} />
          <Text style={[styles.countText, { color: colors.secondaryForeground }]}>
            {filteredStories.length} histórias
          </Text>
        </View>
      </View>

      {filteredStories.length > 0 ? (
        <View style={styles.results}>
          {filteredStories.map((story) => (
            <StoryRow key={story.id} story={story} onPress={() => openStory(story)} />
          ))}
        </View>
      ) : (
        <EmptyState
          icon="search"
          title="Nenhum mundo encontrado"
          description="Tente outro título ou escolha um gênero diferente."
        />
      )}
    </ScreenPage>
  );
}

const styles = StyleSheet.create({
  searchBox: {
    minHeight: 50,
    borderWidth: 1,
    borderRadius: 15,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  searchInput: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 11, paddingVertical: 12 },
  genreList: { gap: 8, paddingRight: 18 },
  catalogHeading: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
    marginTop: -2,
  },
  resultCount: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 9,
    paddingVertical: 6,
    borderRadius: 8,
    marginBottom: 3,
  },
  countText: { fontFamily: 'Inter_600SemiBold', fontSize: 9 },
  results: { gap: 10 },
});
