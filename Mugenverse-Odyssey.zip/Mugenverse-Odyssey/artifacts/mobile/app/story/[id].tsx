import React from 'react';
import {
  ImageBackground,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Feather } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { PrimaryButton } from '@/components/MugenverseUI';
import { findStory } from '@/data/stories';
import { useAppState } from '@/context/AppContext';
import type { StoryChoice } from '@/data/stories';

export default function StoryScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { id: routeId } = useLocalSearchParams<{ id: string }>();
  const storyId = String(routeId ?? '');
  const {
    customStories,
    journeys,
    startAdventure,
    chooseStoryOption,
  } = useAppState();
  const story = findStory(storyId, customStories);
  const journey = journeys[storyId];
  const scene = story && journey ? story.scenes[journey.sceneIndex] : undefined;

  if (!story) {
    return (
      <SafeAreaView style={[styles.notFound, { backgroundColor: colors.background }]}>
        <Feather name="map" size={28} color={colors.primary} />
        <Text style={[styles.notFoundTitle, { color: colors.foreground }]}>
          Esta história não está disponível
        </Text>
        <PrimaryButton label="VOLTAR" onPress={() => router.back()} icon="arrow-left" />
      </SafeAreaView>
    );
  }

  const completed = journey?.status === 'completed';

  return (
    <SafeAreaView
      edges={['top']}
      style={[styles.screen, { backgroundColor: colors.background }]}
    >
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingBottom: Math.max(28, insets.bottom + 20),
        }}
      >
        <ImageBackground source={story.cover} style={styles.cover} resizeMode="cover">
          <LinearGradient
            colors={['rgba(8,7,12,0.48)', 'rgba(8,7,12,0.08)', 'rgba(8,7,12,0.98)']}
            locations={[0, 0.42, 1]}
            style={StyleSheet.absoluteFill}
          />
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Voltar"
            onPress={() => router.back()}
            style={[styles.backButton, { top: insets.top ? 12 : 16, borderColor: 'rgba(255,255,255,0.25)' }]}
          >
            <Feather name="arrow-left" size={18} color="#FFFFFF" />
          </Pressable>
          <View style={styles.coverCopy}>
            <Text style={[styles.genre, { color: colors.gold }]}>{story.genre.toUpperCase()}</Text>
            <Text style={styles.title}>{story.title}</Text>
            <Text style={styles.coverMeta}>
              {story.world} · {story.chapterCount} capítulos
            </Text>
          </View>
        </ImageBackground>

        <View style={styles.body}>
          {completed ? (
            <>
              <View style={[styles.completionIcon, { backgroundColor: colors.accent }]}>
                <Feather name="award" size={24} color={colors.gold} />
              </View>
              <Text style={[styles.chapterLabel, { color: colors.gold }]}>JORNADA CONCLUÍDA</Text>
              <Text style={[styles.chapterTitle, { color: colors.foreground }]}>
                Seu caminho agora faz parte deste mundo.
              </Text>
              <Text style={[styles.narration, { color: colors.mutedForeground }]}>
                {journey?.lastConsequence ?? 'Sua aventura chegou ao fim.'}
              </Text>
              <PrimaryButton
                label="JOGAR NOVAMENTE"
                icon="rotate-ccw"
                onPress={() => startAdventure(story.id)}
              />
              <Pressable
                accessibilityRole="button"
                onPress={() => router.push('/(tabs)/library')}
                style={styles.secondaryAction}
              >
                <Text style={[styles.secondaryActionText, { color: colors.mutedForeground }]}>
                  Voltar à biblioteca
                </Text>
              </Pressable>
            </>
          ) : !journey ? (
            <>
              <Text style={[styles.chapterLabel, { color: colors.gold }]}>
                {story.author.toUpperCase()}
              </Text>
              <Text style={[styles.chapterTitle, { color: colors.foreground }]}>
                Uma porta para {story.world}
              </Text>
              <Text style={[styles.narration, { color: colors.mutedForeground }]}>
                {story.description}
              </Text>
              <View style={[styles.infoPanel, { backgroundColor: colors.card, borderColor: colors.border }]}>
                <Feather name="user" size={15} color={colors.primary} />
                <Text style={[styles.infoText, { color: colors.secondaryForeground }]}>
                  Você acompanha {story.protagonist.toLocaleLowerCase('pt-BR')} nesta aventura de escolhas.
                </Text>
              </View>
              <PrimaryButton
                label="ENTRAR NESTE MUNDO"
                icon="arrow-up-right"
                onPress={() => startAdventure(story.id)}
                testID="enter-story-world"
              />
            </>
          ) : scene ? (
            <>
              <Text style={[styles.chapterLabel, { color: colors.gold }]}>
                CAPÍTULO {journey.sceneIndex + 1} · {scene.chapter.toUpperCase()}
              </Text>
              <Text style={[styles.chapterTitle, { color: colors.foreground }]}>
                {story.title}
              </Text>
              <Text style={[styles.narration, { color: colors.foreground }]}>
                {scene.narration}
              </Text>
              {journey.lastConsequence ? (
                <View style={[styles.consequenceCard, { backgroundColor: colors.secondary }]}>
                  <Feather name="corner-down-right" size={14} color={colors.gold} />
                  <Text style={[styles.consequenceText, { color: colors.secondaryForeground }]}>
                    {journey.lastConsequence}
                  </Text>
                </View>
              ) : null}
              <View style={styles.choiceHeader}>
                <Text style={[styles.choicePrompt, { color: colors.mutedForeground }]}>
                  QUAL SERÁ SUA ESCOLHA?
                </Text>
                <View style={[styles.chapterProgress, { backgroundColor: colors.secondary }]}>
                  <View
                    style={[
                      styles.chapterProgressFill,
                      {
                        width: `${Math.round(
                          ((journey.sceneIndex + 1) / story.scenes.length) * 100,
                        )}%`,
                        backgroundColor: colors.primary,
                      },
                    ]}
                  />
                </View>
              </View>
              <View style={styles.choices}>
                {scene.choices.map((choice: StoryChoice, index: number) => (
                  <Pressable
                    key={`${story.id}-${journey.sceneIndex}-${index}`}
                    accessibilityRole="button"
                    testID={`story-choice-${index + 1}`}
                    onPress={() => chooseStoryOption(story.id, choice)}
                    style={({ pressed }) => [
                      styles.choice,
                      {
                        borderColor: pressed ? colors.primary : colors.border,
                        backgroundColor: pressed ? colors.accent : colors.card,
                      },
                    ]}
                  >
                    <View style={[styles.choiceNumber, { backgroundColor: colors.secondary }]}>
                      <Text style={[styles.choiceNumberText, { color: colors.gold }]}>
                        {String(index + 1).padStart(2, '0')}
                      </Text>
                    </View>
                    <Text style={[styles.choiceText, { color: colors.foreground }]}>
                      {choice.label}
                    </Text>
                    <Feather name="arrow-up-right" size={15} color={colors.primary} />
                  </Pressable>
                ))}
              </View>
            </>
          ) : null}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  notFound: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 28, gap: 17 },
  notFoundTitle: { fontFamily: 'Inter_600SemiBold', fontSize: 16, textAlign: 'center' },
  cover: { height: 350, justifyContent: 'flex-end', padding: 22 },
  backButton: {
    position: 'absolute',
    left: 20,
    width: 40,
    height: 40,
    borderRadius: 14,
    borderWidth: 1,
    backgroundColor: 'rgba(8,7,12,0.52)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  coverCopy: { gap: 8 },
  genre: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.5 },
  title: { color: '#FFFFFF', fontFamily: 'Inter_700Bold', fontSize: 28, lineHeight: 34, letterSpacing: -0.6 },
  coverMeta: { color: 'rgba(255,255,255,0.75)', fontFamily: 'Inter_500Medium', fontSize: 10 },
  body: { paddingHorizontal: 22, paddingTop: 22, gap: 16 },
  chapterLabel: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.3, lineHeight: 14 },
  chapterTitle: { fontFamily: 'Inter_700Bold', fontSize: 22, lineHeight: 29, letterSpacing: -0.4 },
  narration: { fontFamily: 'Inter_400Regular', fontSize: 14, lineHeight: 25 },
  infoPanel: { borderWidth: 1, borderRadius: 14, padding: 13, flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  infoText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 16 },
  choiceHeader: { gap: 9, marginTop: 2 },
  choicePrompt: { fontFamily: 'Inter_700Bold', fontSize: 9, letterSpacing: 1.1 },
  chapterProgress: { height: 4, borderRadius: 6, overflow: 'hidden' },
  chapterProgressFill: { height: '100%', borderRadius: 6 },
  choices: { gap: 9 },
  choice: {
    minHeight: 62,
    borderRadius: 15,
    borderWidth: 1,
    padding: 11,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 11,
  },
  choiceNumber: { width: 33, height: 33, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  choiceNumberText: { fontFamily: 'Inter_700Bold', fontSize: 10 },
  choiceText: { flex: 1, fontFamily: 'Inter_600SemiBold', fontSize: 11, lineHeight: 17 },
  consequenceCard: { padding: 13, borderRadius: 14, flexDirection: 'row', gap: 9, alignItems: 'flex-start' },
  consequenceText: { flex: 1, fontFamily: 'Inter_400Regular', fontSize: 10, lineHeight: 16 },
  completionIcon: { width: 54, height: 54, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  secondaryAction: { minHeight: 40, justifyContent: 'center', alignItems: 'center' },
  secondaryActionText: { fontFamily: 'Inter_500Medium', fontSize: 11 },
});
