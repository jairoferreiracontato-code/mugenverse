import AsyncStorage from '@react-native-async-storage/async-storage';
import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import type { ReactNode } from 'react';
import { findStory } from '@/data/stories';
import type {
  AttributeChanges,
  AttributeKey,
  Attributes,
  Story,
  StoryChoice,
} from '@/data/stories';
import {
  INITIAL_ATTRIBUTES,
  applyAttributeChanges,
  resolveChoiceAttributeChanges,
  resolveFreeAction,
} from '@/logic/narrative-engine';
import type { ActionIntent } from '@/logic/narrative-engine';

const STORAGE_KEY = 'mugenverse.local.v1';
const CURRENT_SCHEMA_VERSION = 2 as const;

export type JourneyStatus = 'in-progress' | 'completed';
export type AdventureEventKind =
  | 'chapter'
  | 'decision'
  | 'action'
  | 'encounter'
  | 'milestone';

export interface AdventureEvent {
  id: string;
  kind: AdventureEventKind;
  chapter: string;
  title: string;
  description: string;
  timestamp: number;
  important: boolean;
  attributeChanges?: AttributeChanges;
}

export interface PlayerActionRecord {
  id: string;
  text: string;
  intent: ActionIntent;
  attributeKey: AttributeKey | null;
  outcome: 'favorável' | 'parcial' | 'sem-regra';
  response: string;
  chapter: string;
  timestamp: number;
  attributeChanges: AttributeChanges;
}

export interface DecisionRecord {
  id: string;
  chapter: string;
  choice: string;
  consequence: string;
  timestamp: number;
  important: boolean;
  attributeChanges: AttributeChanges;
}

export interface Journey {
  status: JourneyStatus;
  sceneIndex: number;
  chapter: string;
  attributes: Attributes;
  actions: PlayerActionRecord[];
  decisions: DecisionRecord[];
  events: AdventureEvent[];
  encounteredCharacters: string[];
  lastConsequence?: string;
  updatedAt: number;
}

interface StoredState {
  schemaVersion: typeof CURRENT_SCHEMA_VERSION;
  customStories: Story[];
  journeys: Record<string, Journey>;
  displayName: string;
  notificationsEnabled: boolean;
}

interface AppContextValue extends StoredState {
  isHydrated: boolean;
  storageError: string | null;
  addStory: (story: Story) => void;
  startAdventure: (storyId: string) => void;
  chooseStoryOption: (storyId: string, choice: StoryChoice) => void;
  submitFreeAction: (storyId: string, action: string) => boolean;
  setDisplayName: (name: string) => void;
  setNotificationsEnabled: (enabled: boolean) => void;
}

function makeId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function initialState(): StoredState {
  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    customStories: [],
    journeys: {},
    displayName: 'Viajante',
    notificationsEnabled: true,
  };
}

function makeEvent(
  kind: AdventureEventKind,
  chapter: string,
  title: string,
  description: string,
  timestamp: number,
  important = false,
  attributeChanges?: AttributeChanges,
): AdventureEvent {
  return {
    id: makeId(kind),
    kind,
    chapter,
    title,
    description,
    timestamp,
    important,
    ...(attributeChanges && Object.keys(attributeChanges).length > 0
      ? { attributeChanges }
      : {}),
  };
}

function appendEncounterEvents(
  events: AdventureEvent[],
  encounteredCharacters: string[],
  names: string[] | undefined,
  chapter: string,
  timestamp: number,
): { events: AdventureEvent[]; encounteredCharacters: string[] } {
  const nextCharacters = [...encounteredCharacters];
  const nextEvents = [...events];

  for (const name of names ?? []) {
    const cleanName = name.trim();
    if (!cleanName || nextCharacters.includes(cleanName)) continue;
    nextCharacters.push(cleanName);
    nextEvents.push(
      makeEvent(
        'encounter',
        chapter,
        'Personagem encontrado',
        cleanName,
        timestamp,
        true,
      ),
    );
  }

  return { events: nextEvents, encounteredCharacters: nextCharacters };
}

function createJourney(story: Story): Journey {
  const timestamp = Date.now();
  const firstScene = story.scenes[0];
  const chapter = firstScene?.chapter ?? 'Abertura';
  let events: AdventureEvent[] = [
    makeEvent(
      'chapter',
      chapter,
      'Aventura iniciada',
      `${story.title} · ${story.world}`,
      timestamp,
      true,
    ),
  ];
  let encounteredCharacters: string[] = [];

  if (firstScene) {
    const encounters = appendEncounterEvents(
      events,
      encounteredCharacters,
      firstScene.characters,
      chapter,
      timestamp,
    );
    events = encounters.events;
    encounteredCharacters = encounters.encounteredCharacters;
  }

  return {
    status: 'in-progress',
    sceneIndex: 0,
    chapter,
    attributes: { ...INITIAL_ATTRIBUTES },
    actions: [],
    decisions: [],
    events,
    encounteredCharacters,
    updatedAt: timestamp,
  };
}

function appliedAttributeChanges(
  before: Attributes,
  after: Attributes,
): AttributeChanges {
  const changes: AttributeChanges = {};
  const keys: AttributeKey[] = [
    'strength',
    'intelligence',
    'agility',
    'charisma',
    'vitality',
  ];
  for (const key of keys) {
    const difference = after[key] - before[key];
    if (difference !== 0) changes[key] = difference;
  }
  return changes;
}

function safeAttributes(value: unknown): Attributes {
  const attributes =
    value && typeof value === 'object'
      ? (value as Partial<Attributes>)
      : {};
  const clamp = (candidate: unknown, fallback: number) =>
    typeof candidate === 'number' && Number.isFinite(candidate)
      ? Math.max(1, Math.min(20, Math.round(candidate)))
      : fallback;

  return {
    strength: clamp(attributes.strength, INITIAL_ATTRIBUTES.strength),
    intelligence: clamp(attributes.intelligence, INITIAL_ATTRIBUTES.intelligence),
    agility: clamp(attributes.agility, INITIAL_ATTRIBUTES.agility),
    charisma: clamp(attributes.charisma, INITIAL_ATTRIBUTES.charisma),
    vitality: clamp(attributes.vitality, INITIAL_ATTRIBUTES.vitality),
  };
}

function normalizeJourney(
  value: unknown,
  story: Story | undefined,
): Journey | null {
  if (!value || typeof value !== 'object') return null;
  const saved = value as Partial<Journey>;
  const sceneCount = Math.max(1, story?.scenes.length ?? 1);
  const requestedIndex =
    typeof saved.sceneIndex === 'number' && Number.isFinite(saved.sceneIndex)
      ? Math.floor(saved.sceneIndex)
      : 0;
  const sceneIndex = Math.max(0, Math.min(sceneCount - 1, requestedIndex));
  const scene = story?.scenes[sceneIndex];
  const chapter =
    typeof saved.chapter === 'string' && saved.chapter.length > 0
      ? saved.chapter
      : scene?.chapter ?? 'Capítulo restaurado';

  return {
    status: saved.status === 'completed' ? 'completed' : 'in-progress',
    sceneIndex,
    chapter,
    attributes: safeAttributes(saved.attributes),
    actions: Array.isArray(saved.actions) ? saved.actions : [],
    decisions: Array.isArray(saved.decisions) ? saved.decisions : [],
    events: Array.isArray(saved.events) ? saved.events : [],
    encounteredCharacters: Array.isArray(saved.encounteredCharacters)
      ? [...new Set(saved.encounteredCharacters.filter((name) => typeof name === 'string'))]
      : [],
    ...(typeof saved.lastConsequence === 'string'
      ? { lastConsequence: saved.lastConsequence }
      : {}),
    updatedAt:
      typeof saved.updatedAt === 'number' && Number.isFinite(saved.updatedAt)
        ? saved.updatedAt
        : Date.now(),
  };
}

function normalizeState(saved: Partial<StoredState>): StoredState {
  const base = initialState();
  const customStories = Array.isArray(saved.customStories)
    ? saved.customStories
    : [];
  const rawJourneys =
    saved.journeys && typeof saved.journeys === 'object'
      ? saved.journeys
      : {};
  const journeys: Record<string, Journey> = {};

  for (const [storyId, value] of Object.entries(rawJourneys)) {
    const journey = normalizeJourney(
      value,
      findStory(storyId, customStories),
    );
    if (journey) journeys[storyId] = journey;
  }

  return {
    schemaVersion: CURRENT_SCHEMA_VERSION,
    customStories,
    journeys,
    displayName:
      typeof saved.displayName === 'string' && saved.displayName.trim()
        ? saved.displayName
        : base.displayName,
    notificationsEnabled:
      typeof saved.notificationsEnabled === 'boolean'
        ? saved.notificationsEnabled
        : base.notificationsEnabled,
  };
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const stateRef = useRef<StoredState>(initialState());
  const saveQueueRef = useRef<Promise<void>>(Promise.resolve());
  const [state, setState] = useState<StoredState>(() => stateRef.current);
  const [isHydrated, setIsHydrated] = useState(false);
  const [storageError, setStorageError] = useState<string | null>(null);

  useEffect(() => {
    let mounted = true;
    AsyncStorage.getItem(STORAGE_KEY)
      .then((raw) => {
        if (!raw || !mounted) return;
        const saved = JSON.parse(raw) as Partial<StoredState>;
        const restored = normalizeState(saved);
        stateRef.current = restored;
        setState(restored);
      })
      .catch(() => {
        if (mounted) {
          setStorageError(
            'Não foi possível carregar os dados salvos neste dispositivo.',
          );
        }
      })
      .finally(() => {
        if (mounted) setIsHydrated(true);
      });
    return () => {
      mounted = false;
    };
  }, []);

  const commit = useCallback((change: (current: StoredState) => StoredState) => {
    const current = stateRef.current;
    const next = change(current);
    if (next === current) return;

    stateRef.current = next;
    setState(next);
    saveQueueRef.current = saveQueueRef.current
      .catch(() => undefined)
      .then(() => AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next)))
      .then(() => setStorageError(null))
      .catch(() => {
        setStorageError(
          'Não foi possível salvar as alterações neste dispositivo.',
        );
      });
  }, []);

  const addStory = useCallback(
    (story: Story) => {
      commit((current) => ({
        ...current,
        customStories: [story, ...current.customStories],
      }));
    },
    [commit],
  );

  const startAdventure = useCallback(
    (storyId: string) => {
      commit((current) => {
        const story = findStory(storyId, current.customStories);
        if (!story) return current;
        if (current.journeys[storyId]?.status === 'in-progress') return current;
        return {
          ...current,
          journeys: {
            ...current.journeys,
            [storyId]: createJourney(story),
          },
        };
      });
    },
    [commit],
  );

  const chooseStoryOption = useCallback(
    (storyId: string, choice: StoryChoice) => {
      commit((current) => {
        const story = findStory(storyId, current.customStories);
        const journey = current.journeys[storyId];
        if (!story || !journey || journey.status !== 'in-progress') return current;
        const scene = story.scenes[journey.sceneIndex];
        const currentChoice = scene?.choices.find(
          (candidate) => candidate.label === choice.label,
        );
        if (!scene || !currentChoice) return current;

        const timestamp = Date.now();
        const choiceChanges = resolveChoiceAttributeChanges(currentChoice);
        const nextAttributes = applyAttributeChanges(
          journey.attributes,
          choiceChanges,
        );
        const actualChanges = appliedAttributeChanges(
          journey.attributes,
          nextAttributes,
        );
        const chapter = journey.chapter || scene.chapter;
        const isImportant = currentChoice.important !== false;
        const decision: DecisionRecord = {
          id: makeId('decision'),
          chapter,
          choice: currentChoice.label,
          consequence: currentChoice.consequence,
          timestamp,
          important: isImportant,
          attributeChanges: actualChanges,
        };
        let events = [
          ...journey.events,
          makeEvent(
            'decision',
            chapter,
            `Escolha: ${currentChoice.label}`,
            currentChoice.consequence,
            timestamp,
            isImportant,
            actualChanges,
          ),
        ];
        let encounteredCharacters = [...journey.encounteredCharacters];
        const choiceEncounters = appendEncounterEvents(
          events,
          encounteredCharacters,
          currentChoice.characters,
          chapter,
          timestamp,
        );
        events = choiceEncounters.events;
        encounteredCharacters = choiceEncounters.encounteredCharacters;

        const nextIndex = journey.sceneIndex + 1;
        const isComplete = nextIndex >= story.scenes.length;
        const nextScene = isComplete ? undefined : story.scenes[nextIndex];
        let nextChapter = chapter;

        if (nextScene) {
          nextChapter = nextScene.chapter;
          events = [
            ...events,
            makeEvent(
              'chapter',
              nextChapter,
              `Capítulo iniciado: ${nextChapter}`,
              story.title,
              timestamp,
              false,
            ),
          ];
          const nextEncounters = appendEncounterEvents(
            events,
            encounteredCharacters,
            nextScene.characters,
            nextChapter,
            timestamp,
          );
          events = nextEncounters.events;
          encounteredCharacters = nextEncounters.encounteredCharacters;
        } else {
          events = [
            ...events,
            makeEvent(
              'milestone',
              chapter,
              'Jornada concluída',
              currentChoice.consequence,
              timestamp,
              true,
            ),
          ];
        }

        return {
          ...current,
          journeys: {
            ...current.journeys,
            [storyId]: {
              ...journey,
              status: isComplete ? 'completed' : 'in-progress',
              sceneIndex: isComplete ? story.scenes.length - 1 : nextIndex,
              chapter: nextChapter,
              attributes: nextAttributes,
              decisions: [...journey.decisions, decision],
              events,
              encounteredCharacters,
              lastConsequence: currentChoice.consequence,
              updatedAt: timestamp,
            },
          },
        };
      });
    },
    [commit],
  );

  const submitFreeAction = useCallback(
    (storyId: string, action: string) => {
      const cleanAction = action.trim().replace(/\s+/g, ' ').slice(0, 300);
      if (!cleanAction) return false;
      let submitted = false;

      commit((current) => {
        const story = findStory(storyId, current.customStories);
        const journey = current.journeys[storyId];
        if (!story || !journey || journey.status !== 'in-progress') return current;
        const scene = story.scenes[journey.sceneIndex];
        if (!scene) return current;

        const usedAttributes = journey.actions
          .filter((record) => record.chapter === journey.chapter)
          .map((record) => record.attributeKey)
          .filter((key): key is AttributeKey => key !== null);
        const resolution = resolveFreeAction(
          cleanAction,
          story,
          scene,
          journey.attributes,
          usedAttributes,
        );
        const nextAttributes = applyAttributeChanges(
          journey.attributes,
          resolution.attributeChanges,
        );
        const actualChanges = appliedAttributeChanges(
          journey.attributes,
          nextAttributes,
        );
        const timestamp = Date.now();
        const actionRecord: PlayerActionRecord = {
          id: makeId('action'),
          text: cleanAction,
          intent: resolution.intent,
          attributeKey: resolution.attributeKey,
          outcome: resolution.outcome,
          response: resolution.response,
          chapter: journey.chapter,
          timestamp,
          attributeChanges: actualChanges,
        };
        const actionEvent = makeEvent(
          'action',
          journey.chapter,
          `Ação livre: ${cleanAction}`,
          resolution.response,
          timestamp,
          resolution.outcome === 'favorável' || Object.keys(actualChanges).length > 0,
          actualChanges,
        );
        submitted = true;

        return {
          ...current,
          journeys: {
            ...current.journeys,
            [storyId]: {
              ...journey,
              attributes: nextAttributes,
              actions: [...journey.actions, actionRecord],
              events: [...journey.events, actionEvent],
              lastConsequence: resolution.response,
              updatedAt: timestamp,
            },
          },
        };
      });

      return submitted;
    },
    [commit],
  );

  const setDisplayName = useCallback(
    (displayName: string) => {
      commit((current) => ({ ...current, displayName }));
    },
    [commit],
  );

  const setNotificationsEnabled = useCallback(
    (notificationsEnabled: boolean) => {
      commit((current) => ({ ...current, notificationsEnabled }));
    },
    [commit],
  );

  const value = useMemo(
    () => ({
      ...state,
      isHydrated,
      storageError,
      addStory,
      startAdventure,
      chooseStoryOption,
      submitFreeAction,
      setDisplayName,
      setNotificationsEnabled,
    }),
    [
      state,
      isHydrated,
      storageError,
      addStory,
      startAdventure,
      chooseStoryOption,
      submitFreeAction,
      setDisplayName,
      setNotificationsEnabled,
    ],
  );

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useAppState() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useAppState must be used within AppProvider');
  }
  return context;
}
