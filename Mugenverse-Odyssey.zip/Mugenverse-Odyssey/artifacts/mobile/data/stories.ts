import type { ImageSourcePropType } from 'react-native';

export const GENRES = [
  'Isekai',
  'Fantasia',
  'Romance',
  'Aventura',
  'Reencarnação',
  'Construção de Reino',
  'RPG',
] as const;

export type Genre = (typeof GENRES)[number];

export type AttributeKey =
  | 'strength'
  | 'intelligence'
  | 'agility'
  | 'charisma'
  | 'vitality';

export type Attributes = Record<AttributeKey, number>;
export type AttributeChanges = Partial<Record<AttributeKey, number>>;

export const ATTRIBUTE_LABELS: Record<AttributeKey, string> = {
  strength: 'Força',
  intelligence: 'Inteligência',
  agility: 'Agilidade',
  charisma: 'Carisma',
  vitality: 'Vitalidade',
};

export const ATTRIBUTE_SHORT_LABELS: Record<AttributeKey, string> = {
  strength: 'FOR',
  intelligence: 'INT',
  agility: 'AGI',
  charisma: 'CAR',
  vitality: 'VIT',
};

export interface StoryChoice {
  label: string;
  consequence: string;
  characters?: string[];
  attributeChanges?: AttributeChanges;
}

export interface StoryScene {
  chapter: string;
  narration: string;
  choices: StoryChoice[];
  characters?: string[];
}

export interface Story {
  id: string;
  title: string;
  description: string;
  genre: Genre;
  tags: Genre[];
  world: string;
  protagonist: string;
  author: string;
  chapterCount: number;
  readingTime: string;
  cover: ImageSourcePropType;
  isNew?: boolean;
  isPopular?: boolean;
  isUserCreated?: boolean;
  scenes: StoryScene[];
}

const kingdomCover =
  require('../assets/images/story-kingdom.jpg') as ImageSourcePropType;
const archiveCover =
  require('../assets/images/story-archive.jpg') as ImageSourcePropType;

export const STORIES: Story[] = [
  {
    id: 'coroa-de-cinzas',
    title: 'A Coroa de Cinzas',
    description:
      'Uma nova vida, um trono em ruínas e uma escolha capaz de mudar todo um reino.',
    genre: 'Construção de Reino',
    tags: ['Isekai', 'Reencarnação', 'RPG', 'Construção de Reino'],
    world: 'Aetherion',
    protagonist: 'O herdeiro exilado',
    author: 'Mugenverse Original',
    chapterCount: 12,
    readingTime: '18 min',
    cover: kingdomCover,
    isPopular: true,
    scenes: [
      {
        chapter: 'O despertar',
        characters: ['Conselheiros da corte'],
        narration:
          'O sino do palácio toca três vezes. Você desperta sobre o trono frio, com uma coroa partida nas mãos. Do lado de fora, a capital espera por uma resposta — e seus conselheiros não concordam sobre qual deve ser.',
        choices: [
          {
            label: 'Ouvir o povo na praça',
            consequence:
              'A praça se enche de vozes. Pela primeira vez, a cidade acredita que o novo soberano pode escutá-la.',
          },
          {
            label: 'Reunir os conselheiros',
            consequence:
              'Os mapas de Aetherion são abertos. Você descobre que o perigo está mais perto do que a corte admite.',
          },
        ],
      },
      {
        chapter: 'As muralhas de Aetherion',
        characters: ['Guardiões do portão'],
        narration:
          'A noite cobre os telhados e pequenas luzes surgem além das muralhas. Uma caravana pede abrigo enquanto os guardas avisam que os portões estão vulneráveis.',
        choices: [
          {
            label: 'Abrir os portões e proteger a caravana',
            consequence:
              'A caravana traz notícias e mãos dispostas a ajudar. O reino ganha aliados, mas a defesa da cidade precisa de um novo plano.',
            characters: ['Viajantes da caravana'],
          },
          {
            label: 'Reforçar a defesa primeiro',
            consequence:
              'As muralhas ficam seguras antes do amanhecer. A decisão evita um ataque surpresa, embora a caravana siga viagem.',
          },
        ],
      },
      {
        chapter: 'Uma promessa ao reino',
        narration:
          'No alto da torre, a coroa partida reflete a primeira luz do dia. O reino ainda está ferido, mas agora existe um caminho para reconstruí-lo.',
        choices: [
          {
            label: 'Fazer um pacto com as cidades livres',
            consequence:
              'As cidades livres respondem ao chamado. A reconstrução começa com uma aliança, não com uma ordem.',
            },
          {
            label: 'Começar pela reconstrução da capital',
            consequence:
              'A capital volta a respirar. Pedra por pedra, o reino começa a se reerguer ao redor de seu povo.',
          },
        ],
      },
    ],
  },
  {
    id: 'biblioteca-do-fim',
    title: 'A Biblioteca do Fim',
    description:
      'Cada livro guarda uma vida que poderia ter sido sua. Um deles está escrevendo o futuro.',
    genre: 'Fantasia',
    tags: ['Isekai', 'Fantasia', 'Aventura', 'RPG'],
    world: 'Arquivo de Lúmen',
    protagonist: 'A aprendiz de cartógrafa',
    author: 'Mugenverse Original',
    chapterCount: 8,
    readingTime: '14 min',
    cover: archiveCover,
    isPopular: true,
    isNew: true,
    scenes: [
      {
        chapter: 'O livro sem título',
        narration:
          'A biblioteca não tem janelas, mas uma luz violeta atravessa o teto. Um volume cai sozinho aos seus pés. Na página aberta, sua própria chegada está descrita — com uma linha ainda em branco.',
        choices: [
          {
            label: 'Escrever seu próprio nome',
            consequence:
              'A tinta brilha e a página se abre. Pela primeira vez, uma história aceita uma escolha que não estava prevista.',
          },
          {
            label: 'Procurar quem escreveu o volume',
            consequence:
              'Pegadas luminosas surgem entre as estantes. Alguém esteve ali segundos antes de você.',
          },
        ],
      },
      {
        chapter: 'Entre páginas',
        narration:
          'As estantes mudam de lugar enquanto você avança. Um corredor termina numa porta feita de páginas dobradas; do outro lado, alguém chama pelo seu nome.',
        choices: [
          {
            label: 'Atravessar a porta',
            consequence:
              'O papel se desfaz como névoa. Você encontra uma sala escondida onde as histórias ainda podem ser alteradas.',
          },
          {
            label: 'Seguir as marcas no chão',
            consequence:
              'As marcas levam a um mapa vivo. Uma rota segura aparece entre as prateleiras em movimento.',
          },
        ],
      },
      {
        chapter: 'A última página',
        characters: ['Voz desconhecida entre as estantes'],
        narration:
          'No centro do arquivo, o livro aguarda aberto. As palavras param de surgir e deixam espaço para a sua decisão final.',
        choices: [
          {
            label: 'Deixar a página aberta para todos',
            consequence:
              'O arquivo ganha uma história compartilhada. Ninguém precisará aceitar um destino escrito por outra pessoa.',
          },
          {
            label: 'Guardar o livro em segurança',
            consequence:
              'O livro fica protegido, e você se torna a guardiã de uma possibilidade que ainda pode mudar tudo.',
          },
        ],
      },
    ],
  },
  {
    id: 'lua-sobre-veloria',
    title: 'A Lua Sobre Veloria',
    description:
      'Uma viajante de outro mundo e um cavaleiro sem memória cruzam caminhos sob uma lua dupla.',
    genre: 'Romance',
    tags: ['Romance', 'Isekai', 'Fantasia'],
    world: 'Veloria',
    protagonist: 'A viajante',
    author: 'Mugenverse Original',
    chapterCount: 10,
    readingTime: '16 min',
    cover: archiveCover,
    isNew: true,
    scenes: [
      {
        chapter: 'A ponte de prata',
        characters: ['Cavaleiro sem memória'],
        narration:
          'Duas luas iluminam a ponte antiga. Um cavaleiro oferece a mão para atravessar, mas não consegue lembrar o próprio nome.',
        choices: [
          {
            label: 'Perguntar sobre o passado dele',
            consequence:
              'O cavaleiro compartilha uma memória breve: uma promessa feita sob as mesmas duas luas.',
          },
          {
            label: 'Contar como você chegou a Veloria',
            consequence:
              'A conversa encontra um ritmo tranquilo. Pela primeira vez desde sua chegada, você não se sente sozinha.',
          },
        ],
      },
      {
        chapter: 'A canção esquecida',
        narration:
          'No vilarejo, uma música antiga faz o cavaleiro parar. Ele reconhece a melodia, embora não saiba explicar de onde.',
        choices: [
          {
            label: 'Acompanhar a música até a praça',
            consequence:
              'Uma moradora reconhece o cavaleiro e oferece uma pista sobre sua vida antes do esquecimento.',
            characters: ['Moradora do vilarejo'],
          },
          {
            label: 'Perguntar por uma rota de volta',
            consequence:
              'Você descobre uma passagem entre mundos, mas ela só se abre na próxima lua cheia.',
          },
        ],
      },
      {
        chapter: 'Sob as duas luas',
        narration:
          'A ponte está vazia quando as duas luas se alinham. Um caminho de volta aparece, e o cavaleiro finalmente lembra o que prometeu.',
        choices: [
          {
            label: 'Ficar em Veloria por escolha própria',
            consequence:
              'A jornada continua em Veloria, agora construída por duas pessoas que escolheram caminhar juntas.',
          },
          {
            label: 'Atravessar o portal lado a lado',
            consequence:
              'O portal se fecha atrás de vocês. Um novo mundo aguarda do outro lado da travessia.',
          },
        ],
      },
    ],
  },
  {
    id: 'guilda-do-zero',
    title: 'A Guilda do Zero',
    description:
      'Sem classe, sem equipamento e sem mapa: sua primeira missão começa na fronteira.',
    genre: 'RPG',
    tags: ['Aventura', 'RPG', 'Isekai'],
    world: 'Fronteira de Elda',
    protagonist: 'A aventureira sem classe',
    author: 'Mugenverse Original',
    chapterCount: 6,
    readingTime: '11 min',
    cover: kingdomCover,
    scenes: [
      {
        chapter: 'Primeiro contrato',
        narration:
          'O quadro da guilda está quase vazio. Um contrato amassado promete poucas moedas, mas aponta para uma trilha que ninguém percorre há semanas.',
        choices: [
          {
            label: 'Aceitar a missão sozinho',
            consequence:
              'Você parte leve e sem esperar por ninguém. A trilha começa com passos cuidadosos.',
          },
          {
            label: 'Recrutar alguém na guilda',
            consequence:
              'Uma companheira experiente aceita o contrato. A jornada começa com um plano e uma aliada.',
            characters: ['Companheira da guilda'],
          },
        ],
      },
      {
        chapter: 'A trilha esquecida',
        narration:
          'Marcas recentes interrompem a estrada de terra. A floresta está silenciosa demais para ser apenas uma manhã tranquila.',
        choices: [
          {
            label: 'Investigar as marcas',
            consequence:
              'As marcas revelam uma passagem escondida entre as árvores.',
          },
          {
            label: 'Seguir direto até o objetivo',
            consequence:
              'Você mantém o ritmo e alcança a clareira antes que o tempo mude.',
          },
        ],
      },
      {
        chapter: 'O próximo nível',
        narration:
          'A missão está concluída. A guilda registra seu nome e deixa uma nova rota aberta no mapa.',
        choices: [
          {
            label: 'Explorar a nova rota',
            consequence:
              'Uma aventura maior começa além da fronteira de Elda.',
          },
          {
            label: 'Voltar à guilda para planejar',
            consequence:
              'Você retorna com experiência e um plano melhor para a próxima missão.',
          },
        ],
      },
    ],
  },
  {
    id: 'jardins-de-celeste',
    title: 'Os Jardins de Celeste',
    description:
      'Cultive uma ilha suspensa, descubra seus segredos e decida quem poderá chamá-la de lar.',
    genre: 'Construção de Reino',
    tags: ['Fantasia', 'Aventura', 'Construção de Reino'],
    world: 'Arquipélago Celeste',
    protagonist: 'A guardiã da ilha',
    author: 'Mugenverse Original',
    chapterCount: 9,
    readingTime: '15 min',
    cover: archiveCover,
    isNew: true,
    scenes: [
      {
        chapter: 'A ilha adormecida',
        narration:
          'O jardim flutua acima das nuvens, tomado por raízes e caminhos apagados. Um pequeno sino toca quando você pisa no primeiro degrau.',
        choices: [
          {
            label: 'Restaurar a fonte central',
            consequence:
              'A água retorna ao jardim e revela sementes raras entre as pedras.',
          },
          {
            label: 'Explorar as casas vazias',
            consequence:
              'Você encontra mapas e histórias de quem viveu na ilha antes do silêncio.',
          },
        ],
      },
      {
        chapter: 'Sementes para o céu',
        characters: ['Viajantes da embarcação'],
        narration:
          'O vento traz uma embarcação até a borda da ilha. Seus passageiros buscam um lugar seguro para começar de novo.',
        choices: [
          {
            label: 'Receber os viajantes',
            consequence:
              'O jardim ganha novas vozes e mãos para ajudar na restauração.',
          },
          {
            label: 'Conhecer cada pessoa primeiro',
            consequence:
              'A confiança cresce devagar. Você descobre por que cada viajante deixou seu antigo lar.',
          },
        ],
      },
      {
        chapter: 'Um lar entre as nuvens',
        narration:
          'O primeiro canteiro floresce. A ilha já não parece abandonada, e a próxima decisão é sobre o futuro de sua comunidade.',
        choices: [
          {
            label: 'Abrir o jardim a todos',
            consequence:
              'Celeste se torna um refúgio aberto, cuidado por todos que chegam.',
          },
          {
            label: 'Preservar a ilha como santuário',
            consequence:
              'O jardim permanece protegido, guardando seus segredos para as gerações futuras.',
          },
        ],
      },
    ],
  },
];

export const HERO_IMAGE =
  require('../assets/images/hero-world.jpg') as ImageSourcePropType;

export function findStory(
  id: string,
  customStories: Story[] = [],
): Story | undefined {
  return STORIES.find((story) => story.id === id) ??
    customStories.find((story) => story.id === id);
}
