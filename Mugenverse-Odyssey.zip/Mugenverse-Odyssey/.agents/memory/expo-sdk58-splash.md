---
name: Expo SDK 58 splash config
description: An Expo SDK 58 app.json schema constraint discovered while configuring the mobile app.
---

Do not add a top-level `splash` object to this Expo SDK 58 scaffold without confirming it is accepted by the installed schema. Use the supported Expo splash-screen configuration path for this SDK.

**Why:** Expo Doctor rejected the top-level `splash` property as an additional, unsupported field.

**How to apply:** Run `expo-doctor` after Expo configuration changes. Keep the app icon configured separately, and use the app theme and `userInterfaceStyle` for the dark launch experience unless the SDK's supported splash configuration is confirmed.
